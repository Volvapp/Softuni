package softuni.exam.models.entity;

public enum StarType {

    RED_GIANT, WHITE_DWARF, NEUTRON_STAR
}
